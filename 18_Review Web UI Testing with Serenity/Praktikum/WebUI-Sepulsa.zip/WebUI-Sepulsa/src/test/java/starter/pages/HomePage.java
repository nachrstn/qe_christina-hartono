package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class HomePage extends PageObject {
    private By title() {
        return By.className("title");
    }
    private By masukButton() {
        return By.id("button_signin_home");
    }
    private By pulsaButton() {
        return By.id("Pulsa");
    }
    @Step
    public void validateOnHomePage() {
        $(title()).isDisplayed();
    }
    @Step
    public boolean validateOnLHomePage() {
        return $(masukButton()).isDisplayed();
    }
    @Step
    public boolean validateOnLHomePageSepulsa() {
        return $(masukButton()).isDisplayed();
    }

    @Step
    public void clickMasukButton() {
        $(masukButton()).click();
    }
    @Step
    public void clickPulsaButton() {
        $(pulsaButton()).click();
    }
}

