package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.CheckoutPage;
import starter.pages.HomePage;
import starter.pages.LoginPage;
import starter.pages.PulsaPage;

public class LoginSteps {
    @Steps
    LoginPage loginPage;

    @Steps
    HomePage homePage;

    @Steps
    PulsaPage pulsaPage;
    @Steps
    CheckoutPage checkoutPage;

//    @Given("I am on the login page")
//    public void onTheLoginPage() {
//        loginPage.openUrl("https://www.sepulsa.com/signin");
//        loginPage.validateOnLoginPage();
//    }

    @Given("I am on the home page")
    public void onTheHomePage() {
        homePage.openUrl("https://www.sepulsa.com");
        homePage.validateOnLHomePage();
    }

    @When("I click masuk button")
    public void clickMasukButton() {
        homePage.clickMasukButton();
    }

    @And("I input valid email")
    public void inputValidEmail() {
        loginPage.inputValidEmail("mariachristinahartono@gmail.com");
    }

    @And("I input invalid password")
    public void inputInvalidPassword() {
        loginPage.inputInvalidPassword("123");
    }

    @And("I click login button")
    public void clickLoginButton() {
        loginPage.clickLoginButton();
    }

    @Then("I can see error message {string}")
    public void validateErrorMessage(String message) {
        loginPage.validateErrorMessageIsDisplayed();
        loginPage.validateEqualErrorMessage(message);
    }


    @And("I input valid password")
    public void inputValidPassword() {
        loginPage.inputPassword("Chris.123");
    }



    @Then("I am on the home page Sepulsa")
    public void onTheHomePageSepulsa() {
        homePage.validateOnLHomePageSepulsa();
    }

    //CHOOSE PRODUCT
    @When("I click pulsa icon")
    public void clickPulsaIcon() {
        homePage.clickPulsaButton();
    }
    @And("I input phone number")
    public void inputNumberPhone() {
        pulsaPage.inputPhoneNumber("085646925270");
    }

    @Then("I have choose feature")
    public void haveChooseFeature() {
        pulsaPage.validateChooseFeature();
    }

    //CHOOSE PAYMENT METHOD
    @And("I click on the pulsa amount")
    public void clickOnPulsaAmount() {
        pulsaPage.clickPulsaAmount();
    }
    @And("I input email")
    public void inputGuestEmail() {
        checkoutPage.inputEmail("mariachristinahartono@gmail.com");
    }
    @And("I choose payment method")
    public void choosePaymentMethod() {
        checkoutPage.clickPaymentMethod();
    }

    @Then("Payment method will chosen")
    public void PaymentMethodChosen() {
        checkoutPage.validatePaymentMethod();
    }




//    @When("I input locked username")
//    public void inputLockedUsername() {
//        loginPage.inputUserName("locked_out_user");
//    }
//
//
//
//    @When("I input {string} username")
//    public void iInputUsername(String username) {
//        loginPage.inputUserName(username);
//    }

}
