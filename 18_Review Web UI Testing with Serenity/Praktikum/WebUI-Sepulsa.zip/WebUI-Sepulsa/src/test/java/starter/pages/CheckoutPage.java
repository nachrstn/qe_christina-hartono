package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class CheckoutPage extends PageObject {
    private By paymentMethod() {
        return By.id("label Gopay");
    }
    private By checkedPayment() {
        return By.id("checkbox Gopay");
    }
    private By guestEmailField() {
        return By.id("guest_email");
    }
    @Step
    public void inputEmail(String email) {
        $(guestEmailField()).type(email);
    }
    @Step
    public void clickPaymentMethod() {
        $(paymentMethod()).click();
    }
    @Step
    public boolean validatePaymentMethod() {
        return $(checkedPayment()).isDisplayed();
    }

}
