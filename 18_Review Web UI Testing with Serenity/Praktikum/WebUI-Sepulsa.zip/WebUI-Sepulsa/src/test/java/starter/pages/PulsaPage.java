package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class PulsaPage extends PageObject {
    private By phoneNumberField() {
        return By.id("phone_number");
    }
    private By chooseFeature() {
        return By.id("phone_number");
    }
    private By pulsaAmount() {
        return By.id("Indosat Rp5.000");
    }
    @Step
    public void inputPhoneNumber(String phonenumber) {
        $(phoneNumberField()).type(phonenumber);
    }
    @Step
    public void validateChooseFeature() {
        $(chooseFeature()).isDisplayed();
    }
    @Step
    public void clickPulsaAmount() {
        $(pulsaAmount()).click();
    }
}
