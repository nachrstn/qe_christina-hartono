package starter.registration;

import net.thucydides.core.annotations.Step;

public class JobListing {
    @Step("I am logged in to my account")
    public void loggedInToMyAccount() {
        System.out.println("I am logged in to my account");
    }

    @Step("I view a job listing")
    public void viewJobListing () {
        System.out.println("I view a job listing");
    }
    @Step("I click the Save button")
    public void clickTheSaveButton() {
        System.out.println("I click the Save button");
    }
    @Step("The job listing should be saved to my profile")
    public void jobListingSaved() {
        System.out.println("The job listing should be saved to my profile");
    }
    @Step("my profile should be updated successfully")
    public void updatedSuccessfully () {
        System.out.println("my profile should be updated successfully ");
    }

}
