package starter.registration;

import net.thucydides.core.annotations.Step;

public class SendMessage {
    @Step("I have logged in to my account")
    public void loggedInAccount() {
        System.out.println("I have logged in to my account");
    }
    @Step("I visit a connection’s profile")
    public void visitConnectionProfile() {
        System.out.println("I visit a connection’s profile");
    }
    @Step("I send a message")
    public void sendMessage() {
        System.out.println("I send a message");
    }
    @Step("the message should be sent successfully")
    public void messageSentSuccessfully() {
        System.out.println("the message should be sent successfully");
    }

}
