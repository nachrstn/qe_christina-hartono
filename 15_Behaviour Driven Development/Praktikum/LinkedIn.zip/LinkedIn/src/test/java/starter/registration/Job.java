package starter.registration;

import net.thucydides.core.annotations.Step;

public class Job {
    @Step("I am logged in to my LinkedIn account")
    public void LoggedInToLinkedIn() {
        System.out.println("I am logged in to my LinkedIn account");
    }

    @Step("I enter job search criteria")
    public void EnterJobSearchCriteria() {
        System.out.println("I enter job search criteria");
    }
    @Step("I click the Search button")
    public void ClickTheSearchButton() {
        System.out.println("I click the Search button");
    }
    @Step("I should see a list of job openings")
    public void SeeAListOfJobOpenings() {
        System.out.println("I should see a list of job openings");
    }
}
