package starter.registration;

import net.thucydides.core.annotations.Step;

public class ReceiveMessage {

    @Step("I am already logged in")
    public void loggedIn() {
        System.out.println("I am already logged in");
    }
    @Step("I receive a new message")
    public void receiveMessage() {
        System.out.println("I receive a new message");
    }
    @Step("I should see the message in my inbox")
    public void seeInbox() {
        System.out.println("I should see the message in my inbox");

    }
}
