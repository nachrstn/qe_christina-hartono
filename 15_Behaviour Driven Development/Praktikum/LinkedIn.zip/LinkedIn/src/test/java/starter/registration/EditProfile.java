package starter.registration;

import net.thucydides.core.annotations.Step;

public class EditProfile {
    @Step("I am already logged in to my LinkedIn account")
    public void alreadyLoggedIn() {
        System.out.println("I’m already logged in to my LinkedIn account");
    }

    @Step("I navigate to the Edit Profile page")
    public void navigateToEditProfile() {
        System.out.println("I navigate to the Edit Profile page");
    }
    @Step("I update my profile information")
    public void updateProfile() {
        System.out.println("I update my profile information");
    }
    @Step("I save the changes")
    public void saveTheChanges() {
        System.out.println("I save the changes");
    }
    @Step("my profile should be updated successfully")
    public void updatedSuccessfully () {
        System.out.println("my profile should be updated successfully ");
    }

}
