package starter.registration;

import net.thucydides.core.annotations.Step;

public class UploadProfilePhoto {
    @Step("I have logged in to my LinkedIn account")
    public void haveLoggedInAccount() {
        System.out.println("I have logged in to my LinkedIn account");
    }

    @Step("I click on the Edit Profile page")
    public void clickEditProfile() {
        System.out.println("I click on the Edit Profile page");
    }
    @Step("I upload a new profile photo")
    public void uploadProfilePhoto() {
        System.out.println("I upload a new profile photo");
    }
    @Step("I am saving the change")
    public void savingTheChange() {
        System.out.println("I am saving the change");
    }
    @Step("my profile photo should be updated")
    public void profilePhotoUpdated() {
        System.out.println("my profile photo should be updated ");
    }

}
