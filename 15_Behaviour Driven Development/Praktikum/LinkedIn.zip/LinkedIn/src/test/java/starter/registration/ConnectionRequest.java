package starter.registration;

import net.thucydides.core.annotations.Step;

public class ConnectionRequest {
    @Step("I am open LinkedIn application")
    public void openLinkedInApp() {
        System.out.println("I am open LinkedIn application");
    }
    @Step("I receive a connection request")
    public void receiveConnectionReq() {
        System.out.println("I receive a connection request");
    }
    @Step("I click the check button")
    public void clickCheckButton() {
        System.out.println("I click the check button");
    }

}
