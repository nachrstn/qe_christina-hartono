package starter.registration;

import net.thucydides.core.annotations.Step;

public class Registration {
    @Step("I am on the LinkedIn homepage")
    public void onTheLinkedInHomepage() {

        System.out.println("I am on the LinkedIn homepage");
    }
    @Step("I click on the Join now button")
    public void joinNowButton() {

        System.out.println("I click on the Join now button");
    }
    @Step("I fill in valid registration details")
    public void validRegistrationDetails() {
        System.out.println("I fill in valid registration details");
    }
    @Step("I click the Join button")
    public void clickTheJoinButton() {
        System.out.println("I click the Join button");
    }
    @Step("I should be redirected to the dashboard")
    public void redirectedToTheDashboard() {
        System.out.println("I should be redirected to the dashboard");
    }
}

