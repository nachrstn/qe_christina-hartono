package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.registration.*;

public class LinkedInSteps {
    @Steps
    Registration registration;

    @Steps
    Job job;
    @Steps
    JobListing jobListing;
    @Steps
    EditProfile editProfile;
    @Steps
    UploadProfilePhoto upProfilePhoto;
    @Steps
    ConnectionRequest connectionReq;
    @Steps
    SendMessage sendMessage;
    @Steps
    ReceiveMessage receiveMessage;

//    Registration
    @Given("I am on the LinkedIn homepage")
    public void onTheLinkedInHomepage() {
        registration.onTheLinkedInHomepage();
    }
    @When("I click on the Join now button")
    public void joinNowButton() {
        registration.joinNowButton();
    }
    @And("I fill in valid registration details")
    public void validRegistrationDetails() {

        registration.validRegistrationDetails();
    }
    @And("I click the Join button")
    public void clickTheJoinButton() {

        registration.clickTheJoinButton();
    }
    @Then("I should be redirected to the dashboard")
    public void redirectedToTheDashboard() {

        registration.redirectedToTheDashboard();
    }


//    Search Job
    @Given("I am logged in to my LinkedIn account")
    public void LoggedInToLinkedIn() {
        job.LoggedInToLinkedIn();
    }

    @When("I enter job search criteria")
    public void EnterJobSearchCriteria() {
        job.EnterJobSearchCriteria();    }

    @And("I click the Search button")
    public void ClickTheSearchButton() {
        job.ClickTheSearchButton();    }

    @Then("I should see a list of job openings")
    public void SeeAListOfJobOpenings() {
        job.SeeAListOfJobOpenings();    }

//    Saved Job Listing
    @Given("I am logged in to my account")
    public void loggedInToMyAccount() {
        jobListing.loggedInToMyAccount();
    }

    @When("I view a job listing")
    public void viewJobListing() {
        jobListing.viewJobListing();    }

    @And("I click the Save button")
    public void clickTheSearchButton() {
        jobListing.clickTheSaveButton();    }

    @Then("The job listing should be saved to my profile")
    public void jobListingSaved () {
        jobListing.jobListingSaved();    }

//    Edit Profile
    @Given("I am already logged in to my LinkedIn account")
    public void alreadyLoggedIn() {
        editProfile.alreadyLoggedIn();
    }

    @When("I navigate to the Edit Profile page")
    public void navigateToEditProfile() {
        editProfile.navigateToEditProfile();    }

    @And("I update my profile information")
    public void updateProfile() {
        editProfile.updateProfile();    }

    @And("I save the changes")
    public void saveTheChanges() {
        editProfile.saveTheChanges ();    }
    @Then("my profile should be updated successfully")
    public void updatedSuccessfully() {
        editProfile.updatedSuccessfully();    }

//    Upload Profile Photo
    @Given("I have logged in to my LinkedIn account")
    public void haveLoggedInAccount() {
        upProfilePhoto.haveLoggedInAccount();
    }

    @When("I click on the Edit Profile page")
    public void clickEditProfile() {
        upProfilePhoto. clickEditProfile();    }

    @And("I upload a new profile photo")
    public void uploadProfilePhoto () {
        upProfilePhoto.uploadProfilePhoto();    }

    @And("I am saving the change")
    public void savingTheChange() {
        upProfilePhoto.savingTheChange ();    }

    @Then("my profile photo should be updated")
    public void profilePhotoUpdated() {
        upProfilePhoto.profilePhotoUpdated();    }

    //Notification Request
    @Given("I am open LinkedIn application")
    public void openLinkedInApp() {
        connectionReq.openLinkedInApp();
    }

    @When("I receive a connection request")
    public void receiveConnectionReq() {
        connectionReq.receiveConnectionReq();    }

    @Then("I click the check button")
    public void clickCheckButton () {
        connectionReq.clickCheckButton();    }

    // Send Message
    @Given("I have logged in to my account")
    public void loggedInAccount() {
        sendMessage.loggedInAccount();
    }

    @When("I visit a connection’s profile")
    public void visitConnectionProfile() {
        sendMessage.visitConnectionProfile();    }

    @And("I send a message")
    public void sendMessage () {
        sendMessage.sendMessage();    }

    @Then("the message should be sent successfully")
    public void messageSentSuccessfully() {
        sendMessage.messageSentSuccessfully ();    }

    //Receive Message
    @Given("I am already logged in")
    public void loggedIn() {
        receiveMessage.loggedIn();
    }

    @When("I receive a new message")
    public void receiveMessage() {
        receiveMessage.receiveMessage();    }

    @Then("I should see the message in my inbox")
    public void seeInbox() {
        receiveMessage.seeInbox();    }

}
