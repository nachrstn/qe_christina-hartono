package starter.sepulsa;

import net.thucydides.core.annotations.Step;

public class Login {
    @Step("I am on the login page")
    public void onTheLoginPage() {
        System.out.println("I am on the login page");
    }
    @Step("I enter valid login credentials")
    public void validCredentials() {
        System.out.println("I enter valid login credentials");
    }
    @Step("I click the Log In button")
    public void clickLogInButton() {
        System.out.println("I click the Log In button");
    }
    @Step("I should be logged in successfully")
    public void loggedInSuccessfully() {
        System.out.println("I should be logged in successfully");
    }

}
