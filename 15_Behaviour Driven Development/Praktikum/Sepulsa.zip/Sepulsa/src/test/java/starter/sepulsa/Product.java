package starter.sepulsa;

import net.thucydides.core.annotations.Step;

public class Product {
    @Step("I am logged in to my account")
    public void loggedAccount() {
        System.out.println("I am logged in to my account");
    }
    @Step("I select a product to purchase")
    public void selectProduct() {
        System.out.println("I select a product to purchase");
    }
    @Step("I go to that product page")
    public void goToProductPage() {
        System.out.println("I go to that product page");
    }

}
