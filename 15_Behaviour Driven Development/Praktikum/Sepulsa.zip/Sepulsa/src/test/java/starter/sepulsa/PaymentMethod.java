package starter.sepulsa;

import net.thucydides.core.annotations.Step;

public class PaymentMethod {
    @Step("I have selected a product")
    public void haveSelectedProduct() {
        System.out.println("I have selected a product");
    }
    @Step("I proceed to the checkout")
    public void proceedCheckout() {
        System.out.println("I proceed to the checkout");
    }
    @Step("I select a payment method")
    public void paymentMethod() {
        System.out.println("I select a payment method");
    }
    @Step("I confirm my purchase")
    public void confirmPurchase() {
        System.out.println("I confirm my purchase");
    }
    @Step("my order should be successfully placed")
    public void orderSuccessfully() {
        System.out.println("my order should be successfully placed ");
    }

}
