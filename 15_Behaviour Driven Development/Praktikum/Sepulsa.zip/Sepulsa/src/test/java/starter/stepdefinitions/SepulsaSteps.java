package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.sepulsa.Login;
import starter.sepulsa.PaymentMethod;
import starter.sepulsa.Product;

public class SepulsaSteps {
    @Steps
    Login login;
    @Steps
    Product product;
    @Steps
    PaymentMethod paymentMethod;
    // Login
    @Given("I am on the login page")
    public void onTheLoginPage() {
        login.onTheLoginPage();
    }

    @When("I enter valid login credentials")
    public void validCredentials() {
        login.validCredentials();
    }

    @And("I click the Log In button")
    public void clickLogInButton() {
        login.clickLogInButton();
    }

    @Then("I should be logged in successfully")
    public void loggedInSuccessfully() {
        login.loggedInSuccessfully();
    }


    // Product
    @Given("I am logged in to my account")
    public void loggedAccount() {
        product.loggedAccount();
    }

    @When("I select a product to purchase")
    public void selectProduct() {
        product.selectProduct();    }

    @Then("I go to that product page")
    public void goToProductPage() {
        product.goToProductPage ();    }

    //Payment Method

    @Given("I have selected a product")
    public void haveSelectedProduct() {
        paymentMethod.haveSelectedProduct();
    }

    @When("I proceed to the checkout")
    public void proceedCheckout() {
        paymentMethod.proceedCheckout();    }

    @And("I select a payment method")
    public void paymentMethod() {
        paymentMethod.paymentMethod();    }

    @And("I confirm my purchase")
    public void confirmPurchase() {
        paymentMethod.confirmPurchase ();    }

    @Then("my order should be successfully placed")
    public void orderSuccessfully() {
        paymentMethod.orderSuccessfully();    }


}