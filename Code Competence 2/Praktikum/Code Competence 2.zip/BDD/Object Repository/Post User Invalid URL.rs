<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Post User Invalid URL</name>
   <tag></tag>
   <elementGuidId>f252c640-5ec8-41ac-a165-3c6461863c28</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <autoUpdateContent>false</autoUpdateContent>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;email\&quot;: \&quot;john@gmail.com\&quot;,\n  \&quot;username\&quot;: \&quot;johnd\&quot;,\n  \&quot;password\&quot;: \&quot;m38rmww\&quot;,\n  \&quot;name\&quot;: {\n    \&quot;firstname\&quot;: \&quot;john\&quot;,\n    \&quot;lastname\&quot;: \&quot;doe\&quot;\n  },\n  \&quot;address\&quot;: {\n    \&quot;geolocation\&quot;: {\n      \&quot;lat\&quot;: \&quot;-37.3159\&quot;,\n      \&quot;long\&quot;: \&quot;81.1496\&quot;\n    },\n    \&quot;city\&quot;: \&quot;kilcoole\&quot;,\n    \&quot;street\&quot;: \&quot;new road\&quot;,\n    \&quot;number\&quot;: 7682,\n    \&quot;zipcode\&quot;: \&quot;12926-3874\&quot;\n  },\n  \&quot;phone\&quot;: \&quot;1-570-236-7033\&quot;\n\t}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>b028e485-345d-417d-af10-3a7723f2754e</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.6.8</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://fakestoreapi.com/urs</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
